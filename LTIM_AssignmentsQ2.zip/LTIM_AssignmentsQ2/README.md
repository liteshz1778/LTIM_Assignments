Postman Collection & Automation Reports: https://drive.google.com/drive/folders/14oqUvspGbsieDkPE_qrlM-8BjFza-yRm?usp=sharing
