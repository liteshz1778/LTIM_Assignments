function fun() {

    var config = {
        baseUrl: "https://restful-booker.herokuapp.com/",
        ContentType: "application/json",
        AcceptVar: "application/json"
    };

    return config;
}