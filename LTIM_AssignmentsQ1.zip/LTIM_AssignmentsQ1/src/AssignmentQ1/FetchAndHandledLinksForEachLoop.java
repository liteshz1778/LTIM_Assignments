package AssignmentQ1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FetchAndHandledLinksForEachLoop {

	WebDriver driver;

	public FetchAndHandledLinksForEachLoop(String browser) {

		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("wedriver.chrome.driver", "D:\\MyFiles\\Testing\\Softwars\\chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.setProperty("webdriver.gecko.driver", "D:\\MyFiles\\Testing\\Softwars\\geckodriver.exe");
			driver = new FirefoxDriver();
		}

	}

	public void handlingLinksForEach() {
		System.out.println("Test-Site is Launching");
		try {
			driver.get("https://www.flipkart.com/");
			driver.manage().window().maximize();
			Thread.sleep(2000);

			List<WebElement> links = driver.findElements(By.tagName("a"));
			System.out.println("Total no. of links Available are: " + links.size());
			int i = 0;
			int j = 0;
			for (WebElement link : links) {

				// Removing the Broken Links along with the null value
				if (!link.getText().equals("") && link.getAttribute("href") != null) {
					System.out.println(i + ")" + " " + link.getText());
					i++;
				} else {
					j++;
				}
			}
			System.out.println("links with specific name: " + i);
			System.out.println("links with no name: " + j);

			System.out.println("Test-Site Luanched Successfully");
			Thread.sleep(2000);
			driver.quit();
		} catch (StaleElementReferenceException st) {
			System.out.println("Other Links are out of DOM");
			driver.quit();
		} catch (Exception e) {

			System.out.println("Exceptions are:\n" + e);
			driver.quit();
		}

	}

	public static void main(String[] args) {

		FetchAndHandledLinksForEachLoop fe = new FetchAndHandledLinksForEachLoop("chrome");
		fe.handlingLinksForEach();
	}

}
