package AssignmentQ1;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FetchAndHandledLinksSquentialStream {

	WebDriver driver;

	public FetchAndHandledLinksSquentialStream(String browser) {

		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("wedriver.chrome.driver", "D:\\MyFiles\\Testing\\Softwars\\chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.setProperty("webdriver.gecko.driver", "D:\\MyFiles\\Testing\\Softwars\\geckodriver.exe");
			driver = new FirefoxDriver();
		}

	}

	public void handlingLinksUsingSequentialStream() {
		System.out.println("Test-Site is Launching");
		try {
			driver.get("https://www.flipkart.com/");
			driver.manage().window().maximize();
			Thread.sleep(2000);

			List<WebElement> links = driver.findElements(By.tagName("a"));
			System.out.println("Total no. of links Available are: " + links.size());

			long totalWorkingLinks = links.stream().filter(link -> link.getAttribute("href") != null).count();
			System.out.println("Total Working Links are: " + totalWorkingLinks);

			List<String> workingLinks = links.stream()
					.filter(link -> !link.getText().isEmpty() && link.getAttribute("href") != null)
					.map(link -> link.getText()).collect(Collectors.toList());
			System.out.println("Working Links Names are:");

			int i = 1;
			for (String workingLink : workingLinks) {
				System.out.println(i + ")" + " " + workingLink);
				i++;
			}

			int noSpecificNameLink = (int) totalWorkingLinks - i;
			System.out.println("Links with No specific names: " + noSpecificNameLink);
			
			System.out.println("Test-Site Luanched Successfully");
			Thread.sleep(8000);
			driver.quit();
		} catch (StaleElementReferenceException st) {
			System.out.println("Other Links are out of DOM");
			driver.quit();
		} catch (Exception e) {
			System.out.println("Exceptions are:\n" + e);
			driver.quit();
		}

	}

	public static void main(String[] args) {

		FetchAndHandledLinksSquentialStream fe3 = new FetchAndHandledLinksSquentialStream("chrome");
		fe3.handlingLinksUsingSequentialStream();

	}

}
