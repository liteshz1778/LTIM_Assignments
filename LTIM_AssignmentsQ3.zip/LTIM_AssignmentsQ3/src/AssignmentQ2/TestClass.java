package AssignmentQ2;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestClass {

	WebDriver driver;
	public HashMap<String, String> hmp1;
	public HashMap<String, String> hmp2;
	SoftAssert sa;
	

	@BeforeClass
	public void setup() {
		System.setProperty("wedriver.chrome.driver", "D:\\MyFiles\\Testing\\Softwars\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Test
	public void m1() throws IOException {

		FileInputStream fis = new FileInputStream(".\\src\\TestData\\StocksDetails.xlsx");

		XSSFWorkbook wb1 = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb1.getSheetAt(0);

		int lastRow = sheet.getLastRowNum();

		hmp1 = new HashMap<String, String>();

		for (int i = 0; i <= lastRow; i++) {

			String key = sheet.getRow(i).getCell(0).getStringCellValue();
			String value = sheet.getRow(i).getCell(1).getStringCellValue();

			hmp1.put(key, value);

		}

		System.out.println("HashMap1: ----------->");
		for (Entry<String, String> keyvalue : hmp1.entrySet()) {

			System.out.println(keyvalue.getKey() + " " + keyvalue.getValue());
		}

		System.out.println("<<<<<<<<<<<<<<<<<<----------->>>>>>>>>>>>>>>>>>>>>");

		hmp2 = new HashMap<String, String>();

		driver.get("https://money.rediff.com/losers/bse/daily/groupall");
		driver.manage().window().maximize();

		JavascriptExecutor js = (JavascriptExecutor) driver;

		WebElement table = driver.findElement(By.xpath("//table[@class=\"dataTable\"]"));

		js.executeScript("arguments[0].scrollIntoView(true);", table);

		int rows = driver.findElements(By.xpath("//table[@class=\"dataTable\"]//tbody//tr")).size();
		System.out.println("Total Static WebSite Data is: "+rows);

		for (int i = 1; i <= 7; i++) {
			String companyName = driver
					.findElement(By.xpath("//table[@class=\"dataTable\"]//tbody//tr[" + i + "]//td[1]")).getText();
			String currentPrice = driver
					.findElement(By.xpath("//table[@class=\"dataTable\"]//tbody//tr[" + i + "]//td[4]")).getText();

			hmp2.put(companyName, currentPrice);
		}

		System.out.println("HashMap2: ----------->");
		for (Entry<String, String> keyvalue : hmp2.entrySet()) {

			System.out.println(keyvalue.getKey() + " " + keyvalue.getValue());
		}

		System.out.println("<<<<<<<<<<<<<<<<<<----------->>>>>>>>>>>>>>>>>>>>>");
		
		 sa = new SoftAssert();

		// Compare the Two HashMaps using equals method:
		System.out.println("Compare HashMap using equals Method: " + hmp1.equals(hmp2)); // output---->false
		sa.assertTrue(hmp1.equals(hmp2));

		// Compare HashMaps for the same set of Keys:
		System.out.println("Compare HashMaps for the same set of Keys: " + hmp1.keySet().equals(hmp2.keySet())); // output---->false
		sa.assertTrue(hmp1.keySet().equals(hmp2.keySet()));
		
		// Find out the Extra keys from the HashMap 1 & 2 By combining it & then
		// extracting only the extra keys
		HashSet<String> hs1 = new HashSet<String>(hmp1.keySet());
		hs1.addAll(hmp2.keySet());
		hs1.removeAll(hmp1.keySet());

		System.out.println("Extra Keys are: " + hs1); // output---------> [Gravity (India), Zinema Media and Ent]

		// Comparing using Values
		// 1. Duplicates are not allowed
		System.out.println("Comparing using Values where Duplicates are not allowed: "
				+ new ArrayList<String>(hmp1.values()).equals(new ArrayList<String>(hmp2.values()))); // output---->false
		sa.assertTrue(new ArrayList<String>(hmp1.values()).equals(new ArrayList<String>(hmp2.values())));
		
		// 2. Duplicates are allowed
		System.out.println("Comparing using Values where Duplicates are allowed: "
				+ new HashSet<String>(hmp1.values()).equals(new HashSet<String>(hmp2.values()))); // output---->false
		sa.assertTrue(new HashSet<String>(hmp1.values()).equals(new HashSet<String>(hmp2.values())));
		sa.assertAll();
	}

	@AfterClass
	public void tearDown() throws InterruptedException {
		Thread.sleep(2000);
		driver.quit();
	}
}

// Console Output ------------------------->

/*
[RemoteTestNG] detected TestNG version 7.4.0
Apr 12, 2024 11:34:06 PM org.openqa.selenium.devtools.CdpVersionFinder findNearestMatch
WARNING: Unable to find an exact match for CDP version 123, returning the closest version; found: 121; Please update to a Selenium version that supports CDP version 123
ERROR StatusLogger Log4j2 could not find a logging implementation. Please add log4j-core to the classpath. Using SimpleLogger to log to the console...
HashMap1: ----------->
Decorous Investme 10.00
Advance Lifestyles 40.76
Metal Coatings ( 80.52
Reliance Infrastruct 197.80
Vinayak Polycon Int. 25.65
Explicit Finance 5.58
Oricon Enterprises L 41.52
Som Datt Finance 134.74
<<<<<<<<<<<<<<<<<<----------->>>>>>>>>>>>>>>>>>>>>
Total Static WebSite Data is: 2243
HashMap2: ----------->
Decorous Investme 10.00
Metal Coatings ( 80.52
Reliance Infrastruct 197.80
Vinayak Polycon Int. 25.65
Oricon Enterprises L 41.52
Som Datt Finance 134.74
Zinema Media and Ent 12.65
<<<<<<<<<<<<<<<<<<----------->>>>>>>>>>>>>>>>>>>>>
Compare HashMap using equals Method: false
Compare HashMaps for the same set of Keys: false
Extra Keys are: [Zinema Media and Ent]
Comparing using Values where Duplicates are not allowed: false
Comparing using Values where Duplicates are allowed: false
FAILED: m1
java.lang.AssertionError: The following asserts failed:
	expected [true] but found [false],
	expected [true] but found [false],
	expected [true] but found [false],
	expected [true] but found [false]
	at org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:47)
	at org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:31)
	at AssignmentQ2.TestClass.m1(TestClass.java:124)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at org.testng.internal.MethodInvocationHelper.invokeMethod(MethodInvocationHelper.java:133)
	at org.testng.internal.TestInvoker.invokeMethod(TestInvoker.java:598)
	at org.testng.internal.TestInvoker.invokeTestMethod(TestInvoker.java:173)
	at org.testng.internal.MethodRunner.runInSequence(MethodRunner.java:46)
	at org.testng.internal.TestInvoker$MethodInvocationAgent.invoke(TestInvoker.java:824)
	at org.testng.internal.TestInvoker.invokeTestMethods(TestInvoker.java:146)
	at org.testng.internal.TestMethodWorker.invokeTestMethods(TestMethodWorker.java:146)
	at org.testng.internal.TestMethodWorker.run(TestMethodWorker.java:128)
	at java.base/java.util.ArrayList.forEach(ArrayList.java:1511)
	at org.testng.TestRunner.privateRun(TestRunner.java:794)
	at org.testng.TestRunner.run(TestRunner.java:596)
	at org.testng.SuiteRunner.runTest(SuiteRunner.java:377)
	at org.testng.SuiteRunner.runSequentially(SuiteRunner.java:371)
	at org.testng.SuiteRunner.privateRun(SuiteRunner.java:332)
	at org.testng.SuiteRunner.run(SuiteRunner.java:276)
	at org.testng.SuiteRunnerWorker.runSuite(SuiteRunnerWorker.java:53)
	at org.testng.SuiteRunnerWorker.run(SuiteRunnerWorker.java:96)
	at org.testng.TestNG.runSuitesSequentially(TestNG.java:1212)
	at org.testng.TestNG.runSuitesLocally(TestNG.java:1134)
	at org.testng.TestNG.runSuites(TestNG.java:1063)
	at org.testng.TestNG.run(TestNG.java:1031)
	at org.testng.remote.AbstractRemoteTestNG.run(AbstractRemoteTestNG.java:115)
	at org.testng.remote.RemoteTestNG.initAndRun(RemoteTestNG.java:251)
	at org.testng.remote.RemoteTestNG.main(RemoteTestNG.java:77)


===============================================
    Default test
    Tests run: 1, Failures: 1, Skips: 0
===============================================


===============================================
Default suite
Total tests run: 1, Passes: 0, Failures: 1, Skips: 0
===============================================


 
 
 
 */

